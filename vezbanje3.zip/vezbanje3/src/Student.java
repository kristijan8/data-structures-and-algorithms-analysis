public class Student {
    protected String index;
    protected Predmet predmet;
    public Student(String index, Predmet predmet) {
        this.index = index;
        this.predmet = predmet;
    }
    public String toString()
    {
        StringBuilder sb=new StringBuilder();
        sb.append(index);
        sb.append(" ");
        sb.append(predmet);
        return sb.toString();
    }
}
