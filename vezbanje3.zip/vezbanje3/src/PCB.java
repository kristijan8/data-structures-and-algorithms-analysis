public class PCB {
    private String ime;
    private int id;
    private int prioritet;
    private int nextID;
    PCB()
    {
        ime="";
        id=prioritet=nextID=0;
    }


    public PCB(String ime, int id, int prioritet) {
        this.ime = ime;
        this.id = id;
        this.prioritet = prioritet;
        this.nextID = 0;
    }
    public void setNext(PCB p)
    {
        nextID=p.id;
    }
    public void setNextID(int n)
    {
        nextID=n;
    }
    public int getPrioritet()
    {return prioritet;}
    public String toString()
    {
        StringBuilder sb=new StringBuilder();
        sb.append(ime);
        sb.append(",");
        sb.append(id);
        sb.append(",");
        sb.append(prioritet);
        return sb.toString();
    }

}
