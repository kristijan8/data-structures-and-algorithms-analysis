public class DLinkedList<E> {
    private Node<E> head,tail;
    DLinkedList()
    {
        head=tail=null;
    }
    public void insertFirst(E t)
    {
        Node<E> nov=new Node<>(t,head,null);
        if(head==null)
        {
            tail=head=nov;
            return;
        }
        head.prev=nov;
        head=nov;
    }
    public void insertLast(E t)
    {
        Node<E> nov=new Node<>(t,null,tail);
        if(head==null)
        {
            insertFirst(t);
            return;
        }
        tail.next=nov;
        tail=nov;
    }
    public void deleteFirst()
    {
        if(head==null)
            return;
        if(head==tail)
        {
            head=tail=null;
            return;
        }
        head=head.next;
        head.prev=null;
    }
    public void deleteLast()
    {
        if(head==null)
            return;
        if(head==tail)
        {
            deleteFirst();
            return;
        }
        tail=tail.prev;
        tail.next=null;
    }
    public void printList()
    {
        if(head==null) {
            System.out.println("Prazna lista");
            return;
        }
        Node<E> dvizi=head;
        while (dvizi.next!=null)
        {
            System.out.print(dvizi.data+","+dvizi.smenet+"<->");
            dvizi=dvizi.next;
        }
        System.out.println(dvizi.data+","+dvizi.smenet);
    }

    public Node<E> getHead() {
        return head;
    }

    public Node<E> getTail() {
        return tail;
    }
    void brisiJazol(E t)
    {
        if(head==null) {
            System.out.println("Prazna e listata");
            return;
        }
        Node<E> dvizi=head;
        while(dvizi.data!=t && dvizi!=tail)
        {
            dvizi=dvizi.next;
        }
        if(dvizi==tail)
        {
            if(tail.data==t)
                deleteLast();
            else
                System.out.println("Nema takov jazol");

            return;
        }

        if(dvizi==head)
            deleteFirst();
//        else if(dvizi==tail)
//            deleteLast();
        else {
            dvizi.prev.next=dvizi.next;
            dvizi.next.prev=dvizi.prev;
        }
    }
    public void premestiPosleden(Node<E> jazol)
    {
        if(head==null || jazol==tail)
            return;
        if(head==jazol)
        {
            insertLast(head.data);
            deleteFirst();
            return;
        }
        insertLast(jazol.data);
        jazol.prev.next = jazol.next;
        jazol.next.prev=jazol.prev;
    }
    public void zameni(Node<E> jazol1,Node<E> jazol2)
    {
        if(jazol1.next==jazol2)
        {
            jazol1.next=jazol2.next;
            jazol2.next.prev=jazol1;

            jazol1.prev.next=jazol2;
            jazol2.prev=jazol1.prev;

            jazol1.prev=jazol2;
            jazol2.next=jazol1;

            jazol1.smeni();
            jazol2.smeni();

            return;
        }
        Node<E> pom1=new Node<>();
        pom1.next=jazol1.next;
        pom1.prev=jazol1.prev;
        if(jazol1!=head)
        {
            jazol1.prev.next = jazol2;
        }
        else head=jazol2;
        jazol1.next.prev = jazol2;
        if(jazol2!=tail)
            jazol2.next.prev=jazol1;
        else tail=jazol1;
        jazol2.prev.next=jazol1;

        jazol1.next=jazol2.next;
        jazol1.prev=jazol2.prev;

        jazol2.next=pom1.next;
        jazol2.prev=pom1.prev;

        jazol1.smeni();
        jazol2.smeni();
    }
}
