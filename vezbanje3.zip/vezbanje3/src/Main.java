import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Main {
    static DLinkedList<Integer> func(DLinkedList<Integer> l1,DLinkedList<Integer> l2)
    {
        DLinkedList<Integer> l=new DLinkedList<>();
        if(l1.getHead()==null||l2.getHead()==null)
        {
            return l;
        }
        Node<Integer> dvizi1,dvizi2;
        dvizi1=l1.getHead();
        dvizi2=l2.getTail();
        while(dvizi1!=null && dvizi2!=null)
        {
            int t1=dvizi1.data+dvizi1.next.data;
            int t2=dvizi2.data+dvizi2.prev.data;
            if(t1==t2)
                l.insertLast(t1);
            else
                l.insertLast(0);

            dvizi2=dvizi2.prev.prev;
            dvizi1=dvizi1.next.next;
        }
        while(dvizi1!=null)
        {
            l.insertLast(dvizi1.data);
            dvizi1=dvizi1.next;
        }
        while(dvizi2!=null)
        {
            l.insertLast(dvizi2.data);
            dvizi2=dvizi2.prev;
        }
        return l;
    }
    static void func1(DLinkedList<Integer> l)
    {
        if(l.getHead()==null)
            return;
        int max,min;
        max=min=l.getHead().data;
        int p1=0,p2=0,p=0;
        Node<Integer> dvizi=l.getHead();
        while(dvizi!=null)
        {
            if(dvizi.data>max)
            {
                max=dvizi.data;
                p1=p;
            }
            else if(dvizi.data<min)
            {
                min=dvizi.data;
                p2=p;
            }
            p++;
            dvizi=dvizi.next;
        }
//        l.brisiJazol(max);
//        l.brisiJazol(min);
        l.insertFirst(p1);
        l.insertFirst(max);
        l.insertLast(min);
        l.insertLast(p2);
    }
    static void func1(DLinkedList<Covek> l,String ime,String prezime,String broj)
    {
        if(l.getHead()==null)
            return;
        Node<Covek> dvizi=l.getHead();
        while(dvizi!=null)
        {
            if(dvizi.data.ime.equals(ime) && dvizi.data.prezime.equals(prezime) && dvizi.data.broj.equals(broj))
            {
                System.out.println("Telefonskiot broj e: "+dvizi.data.telefon);
                return;
            }
            dvizi=dvizi.next;
        }
        System.out.println("Ne e pronajden takov covek");
    }
    static void preslikaj(DLinkedList l1,DLinkedList l2)
    {
        Node dvizi=l2.getHead();
        while(dvizi!=null)
        {
            l1.insertLast(dvizi.data);
            dvizi=dvizi.next;
        }
    }

    static void func3(DLinkedList<Student> l){
        if(l.getHead()==null)
            return;
        DLinkedList<Student> n=new DLinkedList<>();
        DLinkedList<Student> k=new DLinkedList<>();
        Node<Student> dvizi=l.getHead();
        while(dvizi.next!=null)
        {
            if(dvizi.next.data.predmet==dvizi.data.predmet)
            {
                Node<Student> dvizi2=dvizi.next;
                while(dvizi2.data.predmet==dvizi.data.predmet)
                {
                    Node<Student> pom=dvizi2.next;
                    l.premestiPosleden(dvizi2);
                    dvizi2=pom;
                }
                if(dvizi2==null)
                {
                    if(dvizi.data.predmet==Predmet.nap)
                        preslikaj(n,l);
                    else
                        preslikaj(k,l);

                    return;
                }
                else
                {
                    if(dvizi.data.predmet==Predmet.nap)
                    {
                        n.insertLast(dvizi.data);
                        k.insertLast(dvizi2.data);
                    }
                    else
                    {
                        k.insertLast(dvizi.data);
                        n.insertLast(dvizi2.data);
                    }
                }
                dvizi=dvizi2.next;
            }
            else
            {

                if(dvizi.data.predmet==Predmet.nap)
                {
                    n.insertLast(dvizi.data);
                    k.insertLast(dvizi.next.data);
                }
                else
                {
                    k.insertLast(dvizi.data);
                    n.insertLast(dvizi.next.data);
                }
              dvizi=dvizi.next.next;
            }
        }
        if(dvizi.data.predmet==Predmet.nap)
            n.insertLast(dvizi.data);
        else
            k.insertLast(dvizi.data);

        n.printList();
        k.printList();

    }
    static DLinkedList<Integer> func4(DLinkedList<Integer> l1,DLinkedList<Integer> l2)
    {
        DLinkedList<Integer> l=new DLinkedList<>();
        Node<Integer> dvizi1=l1.getHead(),dvizi2=l2.getHead().next;
        boolean t=false;
        while(dvizi1!=null&&dvizi2!=null)
        {
            l.insertLast(dvizi1.data);
            l.insertLast(dvizi2.data);

                dvizi1=dvizi1.next;
                dvizi2=dvizi2.next;
                if(dvizi1==null||dvizi2==null)
                {
                    t=true;
                    break;
                }
                dvizi1=dvizi1.next;
                dvizi2=dvizi2.next;
        }
        if(dvizi1==null&&dvizi2==null)
            return l;
        if(dvizi1==null)
        {
            if(t==true)
                dvizi2=dvizi2.next;
            while(true)
            {
                dvizi1=l1.getTail();
                l.insertLast(dvizi1.data);
                l1.deleteLast();
                l.insertLast(dvizi2.data);
                dvizi2=dvizi2.next;
                if(dvizi2==null)
                    break;
                dvizi2=dvizi2.next;
                if (dvizi2==null)
                    break;
            }
        }
        else if (dvizi2==null)
        {
            if(t==true)
                dvizi1=dvizi1.next;
            while(true)
            {
                l.insertLast(dvizi1.data);
                dvizi2=l2.getTail();
                l.insertLast(dvizi2.data);
                l2.deleteLast();
                dvizi1=dvizi1.next;
                if(dvizi1==null)
                    break;
                dvizi1=dvizi1.next;
                if(dvizi1==null)
                    break;
            }
        }
        return l;
    }
    static boolean func5(String []niza)
    {
        Stack<String> m=new Stack<>();
        for (int i=0;i< niza.length;i++)
        {
            if(niza[i].charAt(0)=='<' && niza[i].charAt(niza.length-1)=='>')
            {
                if(niza[i].charAt(1)!='/')
                {
                    m.push(niza[i]);
                }
                else
                {
                    if(m.peek().substring(1).equals(niza[i].substring(2)))
                        m.pop();
                    else
                        return false;
                }
            }
            else return false;
        }
        if(!m.isEmpty())
            return false;
        return true;
    }
    public static Integer findMin(Integer[] results) {
        int min = -1;
        for (int i = 0; i < results.length; i++) {
            if (min == -1 && results[i] != 0) {
                min = results[i];
            } else {
                if (results[i] < min && results[i] != 0) {
                    min = results[i];
                }
            }
        }
        return min;
    }
    static int func5(int n)
    {
        if(n==1)
            return 0;
        Integer results[]=new Integer[3];

        if(n%3==0) results[0]=1+func5(n/3);
        else results[0]=0;

        if(n%2==0) results[1]=1+func5(n/2);
        else results[1]=0;

        results[2]=1+func5(n-1);
        return findMin(results);

    }
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    static void func6(DLinkedList<Integer> l)
    {
        if(l.getHead()==null)
            return;
        Node<Integer> dvizi=l.getHead();
        while(dvizi.next!=null)
        {
            if(dvizi.smenet==true)
            {
                dvizi=dvizi.next;
                continue;
            }
            Node<Integer> dvizi2=dvizi.next,pom1=dvizi.next;
            while(dvizi2!=null)
            {
                boolean t=true;
                if(dvizi2.smenet==false)
                {
                    if(isPrime(Math.abs(dvizi2.data-dvizi.data)))
                    {
                        l.zameni(dvizi,dvizi2);
                        t=false;
                    }
                }
                if(t==false)
                    break;
                dvizi2=dvizi2.next;
            }
            dvizi=pom1;
        }
    }

    public static void main(String[] args) {

//        DLinkedList<Integer> l1 =new DLinkedList<>();
//        DLinkedList<Integer> l2 =new DLinkedList<>();
//        l1.insertLast(2);
//        l1.insertLast(5);
//        l1.insertLast(7);
//        l1.insertLast(9);
//        l1.insertLast(3);
//        l1.insertLast(3);
//        l1.insertLast(7);
//        l1.insertLast(1);
//        l1.printList();
//
//        l2.insertLast(5);
//        l2.insertLast(3);
//        l2.insertLast(4);
//        l2.insertLast(1);
//        l2.insertLast(5);
//        l2.insertLast(1);
//        l2.insertLast(1);
//        l2.insertLast(5);
//        l2.insertLast(3);
//        l2.insertLast(4);
//        l2.insertLast(4);
//        l2.insertLast(3);
//       // l2.printList();
//
//        DLinkedList<Integer> l3=new DLinkedList<>();
//        l3.insertLast(6);
//        l3.insertLast(4);
//        l3.insertLast(21);
//        l3.insertLast(1);
//        l3.insertLast(19);
//        func1(l3);
//        l3.printList();

//        Scanner scanner=new Scanner(System.in);
//        String covek=scanner.nextLine();
//        String []s=covek.split(" ");
//        Covek c=new Covek(s[0],s[1],s[2],s[3],s[4]);
//        covek=scanner.nextLine();
//        Covek c1=new Covek(s[0],s[1],s[2],s[3],s[4]);
//        DLinkedList<Covek> list=new DLinkedList<>();
//        list.insertLast(c);
//        list.insertLast(c1);


//        Student st=new Student("st1",Predmet.nap);
//        System.out.println(st);
//        DLinkedList<Student> list=new DLinkedList<>();
//        list.insertLast(new Student("st1",Predmet.nap));
//        list.insertLast(new Student("st2",Predmet.nap));
//        list.insertLast(new Student("st3",Predmet.lkda));
//        list.insertLast(new Student("st4",Predmet.lkda));
//        list.insertLast(new Student("st5",Predmet.lkda));
//        list.insertLast(new Student("st6",Predmet.nap));
//        list.insertLast(new Student("st7",Predmet.nap));
//        list.printList();
//        DLinkedList<Student> l1=new DLinkedList<>();
//        DLinkedList<Student> l2=new DLinkedList<>();
//        func3(list);
//        DLinkedList<Integer> list1=new DLinkedList<>();
//        DLinkedList<Integer> list2=new DLinkedList<>();
//        for(int i=1;i<=9;i++)
//        {
//            list1.insertLast(i);
//        }
//        list2.insertLast(10);
//        list2.insertLast(11);
//        list2.insertLast(12);
//        list2.insertLast(14);
//        func4(list1,list2).printList();
//    }
        DLinkedList<Integer> l=new DLinkedList<>();
        l.insertLast(7);
        l.insertLast(8);
        l.insertLast(13);
        l.insertLast(4);
        l.insertLast(11);
        l.insertLast(1);
        l.insertLast(7);
        l.insertLast(4);
        l.insertLast(15);
        l.printList();
        func6(l);
        l.printList();
    }
}