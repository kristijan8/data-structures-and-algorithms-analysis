public enum Predmet {nap,lkda}
