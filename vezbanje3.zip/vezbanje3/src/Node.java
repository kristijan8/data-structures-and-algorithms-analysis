public class Node<E> {
    protected E data;
    protected Node<E> next;
    protected Node<E> prev;
    protected boolean smenet;
    public Node() {
        data=null;
        next=prev=null;
        smenet=false;
    }
    public Node(E data, Node<E> next, Node<E> prev) {
        this.data = data;
        this.next = next;
        this.prev = prev;
        smenet=false;
    }
    public void smeni()
    {
        smenet=true;
    }

}
